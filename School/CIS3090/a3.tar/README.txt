***********************************
Name: Onyeije Chigozie Davis
			0946343
***********************************

Timing results:
No. of iterations/time(s)	1000 	 2000 	  3000 	   4000 	5000 	 6000  	  10000    20000 	40000 	 100000    150000
		Serial				0.14373	 0.26359  0.39432  0.52745  0.68913  0.77353  1.29247  2.54992  5.19770  12.77071  19.13063
	Parallel(inner loops)	4.39034  6.60270  8.89103  11.6427  18.1124  19.4334  33.5828  73.2455  190.336  435.1229  711.7815
	Parallel(outer loop)	4.46175  9.03975  14.9939  18.4268  23.2759  27.8233  46.8218  97.0553  189.944  469.9426  672.6036

Notes: The tests were run on the SOCS nomachine server. For the parallelization, i ran 2 tests: one for when i used the parallel 
	   on the outer/larger for loop, and the other for when i usedthe parallel code on the smaller/inner for loops. Both times, 
	   the program ran slower than the serial code. This is probably due to the fact that this program isnt exactly a large program,
	   so the overhead cost of adding parallel code to it far outweighs the reduction in runtime provided by parallel programming.
