#include <mpi.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h> 
#include <unistd.h> 
#include <stdlib.h>
#include <sys/wait.h>

#define MASTER 0
#define MASTER_TO_SLAVES 1
#define SLAVE_TO_MASTER 2

int count = 0;
int count2 = 0;

int main(int argc, char *argv[]) {
	
	int a;
	if(argc != 2) {
		printf("Not enough command-line arguments to run program\n");
		exit(0);
	}
	
	int numprocesses;    //num of tasks for each process
	int rank; //process id for each process
	int slaves; //number of slaves
	//int source, dest;
	int partition;
	int i, j, k, l, avg, offset, leftover; //offset is current position of the task handler
	int array[4] = {100, 400, 800, 1000};
	MPI_Status status;
	
	
	//create matrices
	int length;
	int numTimes = 4;
	if(strcmp("-g", argv[1]) != 0) {
		length = atoi(argv[1]);
		numTimes = 1;
	}
	
	
	MPI_Init(NULL, NULL);
	
	for(a =0; a<numTimes; a++) {
		if(strcmp("-g", argv[1]) == 0) {
			length = array[a];
		}
		float matA[1][length];
		float matB[length][length];
		float matC[1][length];
		float result[1][length];
		float sum = 0;
		
		MPI_Comm_rank(MPI_COMM_WORLD,&rank);
		MPI_Comm_size(MPI_COMM_WORLD,&numprocesses);
		slaves = numprocesses - 1;
	
		if(rank == MASTER) {
			//initialize arrays
			for(i = 0; i < length; i++) {
				matA[0][i] = i%10;
			}
			for(i = 0; i < length; i++) {
				matC[0][i] = 0;
			}
			for(i = 0; i < length; i++) {
				result[0][i] = 0;
			}
			for(i = 0; i < length; i++) {
				for(j = 0; j < length; j++) {
					matB[i][j] = (i + j)%10;
				}
			}
			
			/*start timer*/
			double start = MPI_Wtime();
			
			if(numprocesses == 1) {
				for (i = 0; i < 1; i++) {
					for (j = 0; j < length; j++) {
						for (k = 0; k < length; k++) {
							sum = sum + matA[i][k] * matB[k][j];
						}
						matC[i][j] += sum;
						sum = 0;
					}
					
				}
			}else{
			
				leftover = length % slaves;
				avg = length / slaves;
				offset = 0;
				for(i = 1; i <= slaves; i++) {
					
					if((i == slaves) && ((length % slaves)!=0)) {
						partition = leftover + avg;
					}else{
						partition = avg;
					}
					MPI_Send(&partition, sizeof(int), MPI_INT, i, MASTER_TO_SLAVES, MPI_COMM_WORLD);
					MPI_Send(&offset, sizeof(int), MPI_INT, i, MASTER_TO_SLAVES, MPI_COMM_WORLD);
					MPI_Send(&matA, 1 * length, MPI_FLOAT, i, MASTER_TO_SLAVES, MPI_COMM_WORLD);
					MPI_Send(&result, 1 * length, MPI_FLOAT, i, MASTER_TO_SLAVES, MPI_COMM_WORLD);
					MPI_Send(&matB[offset][0], partition * length, MPI_FLOAT, i, MASTER_TO_SLAVES, MPI_COMM_WORLD);
					offset = offset + partition;
				}
				
				for(i = 1; i <= slaves; i++) {
					MPI_Recv(&offset, sizeof(int), MPI_INT, i, SLAVE_TO_MASTER, MPI_COMM_WORLD, &status);
					MPI_Recv(&partition, sizeof(int), MPI_INT, i, SLAVE_TO_MASTER, MPI_COMM_WORLD, &status);
					MPI_Recv(&result[0][0], 1 * length, MPI_FLOAT, i, SLAVE_TO_MASTER, MPI_COMM_WORLD, &status);
					for(j = 0; j < length; j++) {
						matC[0][j] += result[0][j];
					}
				}
			}
			
			double end = MPI_Wtime();
			
			if(count == 0) {
				if(strcmp("-g", argv[1]) == 0) {
					printf("N/B: Segfaults always occured when i used matrix sizes over 1000, so i used 100, 400, 800 and 100 instead\nI also couldnt run the simulation/program using different numbers of processes, so i just used the one specified\n\n");
				}
				printf("Size		Processes\n");
			}
			count++;
			if(count2 == 0)printf("			%d\n", numprocesses);
			count2++;
			//printf("--------------%d matrix size and %d processors------------\n", length, numprocesses);
			printf("%d		%f\n", length, end - start);
			
			/*for(i = 0; i < length; i++) {
				printf("%f ", matC[0][i]);
			}*/
			printf("------------------------------------------------------------\n");
		}
		
		int aCol;
		if(rank != MASTER) {
			MPI_Recv(&partition, sizeof(int), MPI_INT, MASTER, MASTER_TO_SLAVES, MPI_COMM_WORLD, &status);
			MPI_Recv(&offset, sizeof(int), MPI_INT, MASTER, MASTER_TO_SLAVES, MPI_COMM_WORLD, &status);
			MPI_Recv(&matA, 1 * length, MPI_FLOAT, MASTER, MASTER_TO_SLAVES, MPI_COMM_WORLD, &status);
			MPI_Recv(&result, 1 * length, MPI_FLOAT, MASTER, MASTER_TO_SLAVES, MPI_COMM_WORLD, &status);
			MPI_Recv(&matB, partition * length, MPI_FLOAT, MASTER, MASTER_TO_SLAVES, MPI_COMM_WORLD, &status);

			for (i = 0; i < 1; i++) {
				for (j = 0; j < length; j++) {
					aCol = offset;
					for (k = 0; k < partition; k++) {
						sum = sum + matA[i][aCol] * matB[k][j];
						aCol++;
					}
					result[i][j] = sum;
					sum = 0;
				}
					
			}
			
			MPI_Send(&offset, 1, MPI_INT, MASTER, SLAVE_TO_MASTER, MPI_COMM_WORLD);
			MPI_Send(&partition, 1, MPI_INT, MASTER, SLAVE_TO_MASTER, MPI_COMM_WORLD);
			MPI_Send(&result, 1 * length,  MPI_FLOAT, MASTER, SLAVE_TO_MASTER, MPI_COMM_WORLD);
			
		}
	}
	MPI_Finalize();
	
}

